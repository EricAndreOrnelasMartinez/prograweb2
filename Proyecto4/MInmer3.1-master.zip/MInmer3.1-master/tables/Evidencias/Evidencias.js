const filefile = document.getElementById('archivo[]')

filefile.addEventListener('change', e =>{
    let pdffile = document.querySelector('archivo')
    console.log(pdffile)
})