<?php 
$con = mysqli_connect('localhost','root','Lasric.2018','Minmer2');
?>