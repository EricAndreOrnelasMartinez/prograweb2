const backbtn = document.getElementById('volver')

backbtn.addEventListener('click', e =>{
    window.history.back()
})